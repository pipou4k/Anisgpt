import { createFileRoute, Link } from "@tanstack/react-router";
import { LANGUAGES } from "@/lib/languages";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "أكاديمية الكود — تعلم لغات البرمجة بالعربي" },
      {
        name: "description",
        content:
          "تعلم البرمجة بالعربية: Python, JavaScript, PHP, C++, HTML, CSS, MySQL, Pawn. دروس مبسطة مع محرر أكواد ومنفذ مباشر.",
      },
      { property: "og:title", content: "أكاديمية الكود — تعلم البرمجة بالعربي" },
      {
        property: "og:description",
        content: "دروس تفاعلية ومحرر أكواد لتشغيل البرامج مباشرة من المتصفح.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen">
      <header className="border-b border-border/50 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-[image:var(--gradient-hero)] font-mono font-bold text-primary-foreground">
              {"</>"}
            </div>
            <span className="text-lg font-bold">أكاديمية الكود</span>
          </div>
          <nav className="text-sm text-muted-foreground">
            {LANGUAGES.length} لغات برمجة
          </nav>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-20 text-center">
        <span className="inline-block rounded-full border border-primary/30 bg-primary/10 px-4 py-1 text-xs font-medium text-primary">
          تعلّم • جرّب • أتقن
        </span>
        <h1 className="mt-6 text-4xl font-bold leading-tight md:text-6xl">
          تعلّم البرمجة بالعربي
          <br />
          <span className="bg-[image:var(--gradient-hero)] bg-clip-text text-transparent">
            من الصفر إلى الاحتراف
          </span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          دروس مبسّطة لكل كلمة مفتاحية في لغتك المفضلة، مع محرر أكواد ومنفّذ
          مباشر داخل المتصفح. اختر لغتك وابدأ الآن.
        </p>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-24">
        <h2 className="mb-6 text-2xl font-bold">اختر لغة البرمجة</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {LANGUAGES.map((lang) => (
            <Link
              key={lang.slug}
              to="/language/$slug"
              params={{ slug: lang.slug }}
              className="group relative overflow-hidden rounded-2xl border border-border bg-[image:var(--gradient-card)] p-6 transition hover:border-primary/50 hover:-translate-y-1"
            >
              <div
                className="mb-4 grid h-14 w-14 place-items-center rounded-xl font-mono text-lg font-bold text-white"
                style={{ backgroundColor: lang.color }}
              >
                {lang.icon}
              </div>
              <h3 className="text-xl font-bold">{lang.name}</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {lang.tagline}
              </p>
              <div className="mt-4 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  {lang.lessons.length} دروس
                </span>
                <span className="text-primary transition group-hover:translate-x-[-4px]">
                  ابدأ ←
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <footer className="border-t border-border/50 py-8 text-center text-sm text-muted-foreground">
        صُنع بحب لمتعلمي البرمجة بالعربية
      </footer>
    </div>
  );
}
