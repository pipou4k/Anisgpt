import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { getLanguage } from "@/lib/languages";
import { CodePlayground } from "@/components/CodePlayground";

export const Route = createFileRoute("/language/$slug")({
  loader: ({ params }) => {
    const lang = getLanguage(params.slug);
    if (!lang) throw notFound();
    return { lang };
  },
  head: ({ loaderData }) => {
    const name = loaderData?.lang?.name ?? "لغة برمجة";
    return {
      meta: [
        { title: `تعلم ${name} — أكاديمية الكود` },
        {
          name: "description",
          content: `دروس ${name} بالعربية مع محرر أكواد ومنفّذ مباشر داخل المتصفح.`,
        },
        { property: "og:title", content: `تعلم ${name} بالعربي` },
        {
          property: "og:description",
          content: `شرح الكلمات المفتاحية في ${name} مع أمثلة وتنفيذ مباشر.`,
        },
        { property: "og:type", content: "article" },
      ],
    };
  },
  component: LanguagePage,
  notFoundComponent: () => (
    <div className="grid min-h-screen place-items-center">
      <div className="text-center">
        <p className="text-lg">اللغة غير موجودة</p>
        <Link to="/" className="mt-4 inline-block text-primary underline">
          عودة للرئيسية
        </Link>
      </div>
    </div>
  ),
  errorComponent: ({ reset }) => (
    <div className="grid min-h-screen place-items-center">
      <button onClick={reset} className="rounded bg-primary px-4 py-2">
        إعادة المحاولة
      </button>
    </div>
  ),
});

function LanguagePage() {
  const { lang } = Route.useLoaderData();
  const [active, setActive] = useState(0);
  const lesson = lang.lessons[active];

  return (
    <div className="min-h-screen">
      <header className="border-b border-border/50 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <Link
            to="/"
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            → عودة
          </Link>
          <div className="flex items-center gap-3">
            <div className="text-end">
              <h1 className="text-lg font-bold">{lang.name}</h1>
              <p className="text-xs text-muted-foreground">{lang.tagline}</p>
            </div>
            <div
              className="grid h-9 w-9 place-items-center rounded-lg font-mono text-sm font-bold text-white"
              style={{ backgroundColor: lang.color }}
            >
              {lang.icon}
            </div>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-6 py-8 lg:grid-cols-[260px_1fr]">
        <aside className="rounded-2xl border border-border bg-card p-4 lg:sticky lg:top-6 lg:h-fit">
          <h2 className="mb-3 px-2 text-sm font-semibold text-muted-foreground">
            الدروس ({lang.lessons.length})
          </h2>
          <nav className="flex flex-col gap-1">
            {lang.lessons.map((l: (typeof lang.lessons)[number], i: number) => (
              <button
                key={l.keyword}
                onClick={() => setActive(i)}
                className={`rounded-lg px-3 py-2 text-right text-sm transition ${
                  i === active
                    ? "bg-primary/15 text-primary"
                    : "text-foreground/80 hover:bg-secondary"
                }`}
              >
                <span className="me-2 text-xs text-muted-foreground">
                  {String(i + 1).padStart(2, "0")}
                </span>
                {l.title}
              </button>
            ))}
          </nav>
        </aside>

        <main className="space-y-6">
          <div className="rounded-2xl border border-border bg-[image:var(--gradient-card)] p-6">
            <div
              className="mb-2 inline-block rounded-md bg-primary/15 px-2 py-0.5 font-mono text-sm text-primary"
              dir="ltr"
            >
              {lesson.keyword}
            </div>
            <h2 className="text-2xl font-bold">{lesson.title}</h2>
            <p className="mt-3 leading-relaxed text-muted-foreground">
              {lesson.description}
            </p>
            <div className="mt-5">
              <div className="mb-2 text-xs font-semibold text-muted-foreground">
                مثال
              </div>
              <pre
                dir="ltr"
                className="overflow-x-auto rounded-xl border border-border bg-[oklch(0.13_0.02_260)] p-4 font-mono text-sm text-foreground"
              >
                {lesson.example}
              </pre>
            </div>
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => setActive(Math.max(0, active - 1))}
                disabled={active === 0}
                className="rounded-lg border border-border px-4 py-2 text-sm disabled:opacity-40"
              >
                → السابق
              </button>
              <span className="text-xs text-muted-foreground">
                {active + 1} / {lang.lessons.length}
              </span>
              <button
                onClick={() =>
                  setActive(Math.min(lang.lessons.length - 1, active + 1))
                }
                disabled={active === lang.lessons.length - 1}
                className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-40"
              >
                التالي ←
              </button>
            </div>
          </div>

          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-xl font-bold">جرّب الكود بنفسك</h2>
              <span className="text-xs text-muted-foreground">
                {lang.piston
                  ? "منفّذ حقيقي عبر السحابة"
                  : lang.preview
                    ? "معاينة مباشرة داخل المتصفح"
                    : "محرر للتدريب"}
              </span>
            </div>
            <CodePlayground language={lang} />
          </div>
        </main>
      </div>
    </div>
  );
}
