export type Lesson = {
  keyword: string;
  title: string;
  description: string;
  example: string;
};

export type Language = {
  slug: string;
  name: string;
  color: string;
  icon: string;
  tagline: string;
  // Piston runtime name (empty => no execution, use preview or none)
  piston?: { language: string; version: string };
  preview?: "html" | "css";
  defaultCode: string;
  lessons: Lesson[];
};

export const LANGUAGES: Language[] = [
  {
    slug: "javascript",
    name: "JavaScript",
    color: "#f7df1e",
    icon: "JS",
    tagline: "لغة الويب التفاعلية",
    piston: { language: "javascript", version: "18.15.0" },
    defaultCode: `console.log("مرحبا بالعالم");\n\nconst nums = [1, 2, 3];\nconst doubled = nums.map(n => n * 2);\nconsole.log(doubled);`,
    lessons: [
      {
        keyword: "console.log()",
        title: "طباعة في الكونسول",
        description: "تُستخدم لطباعة النصوص والقيم في نافذة الكونسول لأغراض التصحيح والاختبار.",
        example: `console.log("Hello");\nconsole.log(1 + 2);`,
      },
      {
        keyword: "let / const / var",
        title: "تعريف المتغيرات",
        description: "let لمتغير قابل للتغيير في نطاق البلوك، const لثابت لا يتغير، var قديمة ونطاقها الدالة.",
        example: `let name = "Ali";\nconst PI = 3.14;\nname = "Sara";`,
      },
      {
        keyword: "function",
        title: "الدوال",
        description: "الدالة كتلة من الكود قابلة لإعادة الاستخدام. يمكن أن تأخذ مدخلات وتُرجع قيمة.",
        example: `function add(a, b) {\n  return a + b;\n}\nconsole.log(add(2, 3));`,
      },
      {
        keyword: "if / else",
        title: "الشروط",
        description: "تنفيذ كود بناءً على شرط معين.",
        example: `const x = 10;\nif (x > 5) {\n  console.log("كبير");\n} else {\n  console.log("صغير");\n}`,
      },
      {
        keyword: "for / while",
        title: "الحلقات",
        description: "تكرار تنفيذ كود عدة مرات.",
        example: `for (let i = 0; i < 3; i++) {\n  console.log(i);\n}`,
      },
      {
        keyword: "Array.map()",
        title: "تحويل المصفوفات",
        description: "تُنشئ مصفوفة جديدة نتيجة تطبيق دالة على كل عنصر.",
        example: `[1,2,3].map(n => n * 10);`,
      },
      {
        keyword: "async / await",
        title: "العمليات غير المتزامنة",
        description: "طريقة أنيقة للتعامل مع الوعود Promises.",
        example: `async function load() {\n  const res = await fetch("/api");\n  const data = await res.json();\n}`,
      },
    ],
  },
  {
    slug: "python",
    name: "Python",
    color: "#3776ab",
    icon: "Py",
    tagline: "لغة بسيطة وقوية للمبتدئين والخبراء",
    piston: { language: "python", version: "3.10.0" },
    defaultCode: `print("مرحبا بالعالم")\n\nnums = [1, 2, 3]\nprint([n * 2 for n in nums])`,
    lessons: [
      {
        keyword: "print()",
        title: "طباعة النصوص",
        description: "دالة لعرض القيم في المخرجات.",
        example: `print("Hello")\nprint(1 + 2)`,
      },
      {
        keyword: "المتغيرات",
        title: "تعريف المتغيرات",
        description: "لا تحتاج لكلمة مفتاحية، فقط اسم = قيمة.",
        example: `name = "Ali"\nage = 20`,
      },
      {
        keyword: "def",
        title: "تعريف الدوال",
        description: "لإنشاء دالة قابلة لإعادة الاستخدام.",
        example: `def add(a, b):\n    return a + b\nprint(add(2, 3))`,
      },
      {
        keyword: "if / elif / else",
        title: "الشروط",
        description: "تنفيذ كود حسب شرط.",
        example: `x = 10\nif x > 5:\n    print("كبير")\nelse:\n    print("صغير")`,
      },
      {
        keyword: "for / while",
        title: "الحلقات",
        description: "تكرار تنفيذ الأوامر.",
        example: `for i in range(3):\n    print(i)`,
      },
      {
        keyword: "list / dict",
        title: "القوائم والقواميس",
        description: "list لتخزين مجموعة عناصر، dict لتخزين أزواج مفتاح-قيمة.",
        example: `nums = [1, 2, 3]\nuser = {"name": "Ali", "age": 20}`,
      },
      {
        keyword: "class",
        title: "البرمجة الكائنية",
        description: "لتعريف كلاس ونماذج (Objects).",
        example: `class Dog:\n    def __init__(self, name):\n        self.name = name\n    def bark(self):\n        print(self.name + " woof!")`,
      },
    ],
  },
  {
    slug: "php",
    name: "PHP",
    color: "#777bb4",
    icon: "PHP",
    tagline: "لغة الخوادم الأكثر انتشاراً",
    piston: { language: "php", version: "8.2.3" },
    defaultCode: `<?php\necho "مرحبا بالعالم\\n";\n$nums = [1, 2, 3];\nforeach ($nums as $n) {\n  echo $n * 2 . "\\n";\n}`,
    lessons: [
      {
        keyword: "<?php ?>",
        title: "وسوم PHP",
        description: "كل كود PHP يبدأ بـ <?php وينتهي بـ ?>.",
        example: `<?php\n  echo "Hello";\n?>`,
      },
      {
        keyword: "echo / print",
        title: "طباعة النصوص",
        description: "echo لعرض المخرجات على المتصفح.",
        example: `<?php echo "Hello World"; ?>`,
      },
      {
        keyword: "$variables",
        title: "المتغيرات",
        description: "كل متغير يبدأ بعلامة $.",
        example: `<?php\n$name = "Ali";\n$age = 20;\n?>`,
      },
      {
        keyword: "function",
        title: "الدوال",
        description: "تعريف دالة قابلة لإعادة الاستخدام.",
        example: `function add($a, $b) {\n  return $a + $b;\n}`,
      },
      {
        keyword: "if / else",
        title: "الشروط",
        description: "التحكم في تدفق الكود.",
        example: `if ($x > 5) {\n  echo "big";\n} else {\n  echo "small";\n}`,
      },
      {
        keyword: "foreach",
        title: "التكرار على المصفوفات",
        description: "المرور على عناصر المصفوفة.",
        example: `foreach ($items as $item) {\n  echo $item;\n}`,
      },
    ],
  },
  {
    slug: "cpp",
    name: "C++",
    color: "#00599c",
    icon: "C++",
    tagline: "لغة قوية وسريعة للأنظمة والألعاب",
    piston: { language: "c++", version: "10.2.0" },
    defaultCode: `#include <iostream>\nusing namespace std;\n\nint main() {\n  cout << "مرحبا بالعالم" << endl;\n  return 0;\n}`,
    lessons: [
      {
        keyword: "#include",
        title: "استيراد المكتبات",
        description: "لتضمين مكتبات جاهزة مثل iostream للإدخال والإخراج.",
        example: `#include <iostream>`,
      },
      {
        keyword: "int main()",
        title: "الدالة الرئيسية",
        description: "نقطة بداية تنفيذ البرنامج.",
        example: `int main() {\n  return 0;\n}`,
      },
      {
        keyword: "cout / cin",
        title: "الإدخال والإخراج",
        description: "cout للطباعة و cin لقراءة المدخلات.",
        example: `int x;\ncin >> x;\ncout << x;`,
      },
      {
        keyword: "المتغيرات",
        title: "أنواع البيانات",
        description: "int, double, char, string, bool.",
        example: `int age = 20;\ndouble pi = 3.14;\nstring name = "Ali";`,
      },
      {
        keyword: "if / else",
        title: "الشروط",
        description: "التحكم في تدفق التنفيذ.",
        example: `if (x > 5) cout << "big";\nelse cout << "small";`,
      },
      {
        keyword: "for / while",
        title: "الحلقات",
        description: "التكرار.",
        example: `for (int i = 0; i < 5; i++) {\n  cout << i;\n}`,
      },
      {
        keyword: "class",
        title: "الكلاسات",
        description: "البرمجة الكائنية في C++.",
        example: `class Dog {\npublic:\n  string name;\n  void bark() { cout << "woof"; }\n};`,
      },
    ],
  },
  {
    slug: "html",
    name: "HTML",
    color: "#e34f26",
    icon: "<>",
    tagline: "لغة بناء صفحات الويب",
    preview: "html",
    defaultCode: `<!DOCTYPE html>\n<html>\n  <head>\n    <title>صفحتي</title>\n  </head>\n  <body>\n    <h1>مرحبا بالعالم</h1>\n    <p>هذه أول صفحة لي</p>\n  </body>\n</html>`,
    lessons: [
      {
        keyword: "<!DOCTYPE html>",
        title: "تعريف نوع المستند",
        description: "يخبر المتصفح أن هذه صفحة HTML5.",
        example: `<!DOCTYPE html>`,
      },
      {
        keyword: "<html> <head> <body>",
        title: "هيكل الصفحة",
        description: "html هو الجذر، head للبيانات الوصفية، body للمحتوى المرئي.",
        example: `<html>\n  <head><title>عنوان</title></head>\n  <body>محتوى</body>\n</html>`,
      },
      {
        keyword: "<h1> - <h6>",
        title: "العناوين",
        description: "عناوين بأحجام مختلفة، h1 الأكبر و h6 الأصغر.",
        example: `<h1>عنوان رئيسي</h1>\n<h2>عنوان فرعي</h2>`,
      },
      {
        keyword: "<p>",
        title: "الفقرات",
        description: "لإضافة فقرة نصية.",
        example: `<p>هذه فقرة</p>`,
      },
      {
        keyword: "<a href>",
        title: "الروابط",
        description: "لإنشاء رابط لصفحة أخرى.",
        example: `<a href="https://example.com">اضغط هنا</a>`,
      },
      {
        keyword: "<img>",
        title: "الصور",
        description: "لعرض صورة.",
        example: `<img src="photo.jpg" alt="وصف" />`,
      },
      {
        keyword: "<ul> <li>",
        title: "القوائم",
        description: "ul قائمة غير مرتبة، ol مرتبة، li عنصر.",
        example: `<ul>\n  <li>عنصر 1</li>\n  <li>عنصر 2</li>\n</ul>`,
      },
    ],
  },
  {
    slug: "css",
    name: "CSS",
    color: "#1572b6",
    icon: "CSS",
    tagline: "تنسيق وتصميم صفحات الويب",
    preview: "css",
    defaultCode: `<style>\n  body {\n    background: #0f172a;\n    color: white;\n    font-family: sans-serif;\n    text-align: center;\n    padding: 40px;\n  }\n  h1 {\n    color: #38bdf8;\n  }\n</style>\n<h1>مرحبا CSS</h1>\n<p>هذه صفحة منسّقة بـ CSS</p>`,
    lessons: [
      {
        keyword: "selector { }",
        title: "المحددات",
        description: "اختيار العناصر لتطبيق التنسيقات عليها.",
        example: `h1 { color: red; }\n.card { padding: 10px; }\n#main { width: 100%; }`,
      },
      {
        keyword: "color / background",
        title: "الألوان",
        description: "color للون النص، background للون الخلفية.",
        example: `body {\n  color: #333;\n  background: #f5f5f5;\n}`,
      },
      {
        keyword: "font",
        title: "الخطوط",
        description: "تنسيق النصوص.",
        example: `p {\n  font-size: 16px;\n  font-weight: bold;\n  font-family: Arial;\n}`,
      },
      {
        keyword: "margin / padding",
        title: "المسافات",
        description: "margin مسافة خارجية، padding مسافة داخلية.",
        example: `.box {\n  margin: 20px;\n  padding: 10px;\n}`,
      },
      {
        keyword: "flex / grid",
        title: "التخطيطات",
        description: "أنظمة تخطيط حديثة لترتيب العناصر.",
        example: `.row {\n  display: flex;\n  gap: 10px;\n}`,
      },
      {
        keyword: "hover / transition",
        title: "التأثيرات",
        description: "تأثيرات تفاعلية عند مرور المؤشر.",
        example: `button {\n  transition: 0.3s;\n}\nbutton:hover {\n  background: blue;\n}`,
      },
    ],
  },
  {
    slug: "mysql",
    name: "MySQL",
    color: "#00758f",
    icon: "SQL",
    tagline: "لغة قواعد البيانات العلائقية",
    defaultCode: `SELECT name, age FROM users\nWHERE age > 18\nORDER BY name ASC;`,
    lessons: [
      {
        keyword: "SELECT",
        title: "استعلام البيانات",
        description: "لجلب بيانات من جدول.",
        example: `SELECT * FROM users;\nSELECT name FROM users;`,
      },
      {
        keyword: "WHERE",
        title: "الشرط",
        description: "لتصفية النتائج حسب شرط.",
        example: `SELECT * FROM users WHERE age > 18;`,
      },
      {
        keyword: "INSERT INTO",
        title: "إدخال بيانات",
        description: "لإضافة سجل جديد.",
        example: `INSERT INTO users (name, age)\nVALUES ('Ali', 20);`,
      },
      {
        keyword: "UPDATE",
        title: "تحديث بيانات",
        description: "لتعديل سجلات موجودة.",
        example: `UPDATE users SET age = 21\nWHERE name = 'Ali';`,
      },
      {
        keyword: "DELETE",
        title: "حذف بيانات",
        description: "لحذف سجلات من جدول.",
        example: `DELETE FROM users WHERE id = 5;`,
      },
      {
        keyword: "CREATE TABLE",
        title: "إنشاء جدول",
        description: "لإنشاء جدول جديد.",
        example: `CREATE TABLE users (\n  id INT PRIMARY KEY,\n  name VARCHAR(50),\n  age INT\n);`,
      },
      {
        keyword: "JOIN",
        title: "دمج الجداول",
        description: "لربط عدة جداول معاً.",
        example: `SELECT u.name, o.total\nFROM users u\nJOIN orders o ON o.user_id = u.id;`,
      },
    ],
  },
  {
    slug: "pawn",
    name: "Pawn",
    color: "#ef4444",
    icon: "PWN",
    tagline: "لغة السكربتات لخوادم الألعاب (SA-MP)",
    defaultCode: `#include <a_samp>\n\nmain() {\n  print("مرحبا بالعالم");\n}\n\npublic OnPlayerConnect(playerid) {\n  SendClientMessage(playerid, 0xFFFFFFFF, "أهلا بك");\n  return 1;\n}`,
    lessons: [
      {
        keyword: "#include",
        title: "استيراد المكتبات",
        description: "لتضمين مكتبات مثل a_samp.",
        example: `#include <a_samp>`,
      },
      {
        keyword: "main()",
        title: "الدالة الرئيسية",
        description: "تُنفذ عند تشغيل السكربت.",
        example: `main() {\n  print("Started");\n}`,
      },
      {
        keyword: "public",
        title: "الدوال العامة (Callbacks)",
        description: "دوال يستدعيها السيرفر عند حدث معين.",
        example: `public OnPlayerConnect(playerid) {\n  return 1;\n}`,
      },
      {
        keyword: "new",
        title: "تعريف المتغيرات",
        description: "استخدم new لتعريف متغير.",
        example: `new score = 0;\nnew name[24];`,
      },
      {
        keyword: "SendClientMessage",
        title: "إرسال رسالة للاعب",
        description: "لإرسال رسالة في شات اللعبة.",
        example: `SendClientMessage(playerid, 0xFF0000FF, "أهلا");`,
      },
      {
        keyword: "if / else",
        title: "الشروط",
        description: "التحكم في تدفق السكربت.",
        example: `if (score > 100) {\n  print("Winner");\n}`,
      },
    ],
  },
];

export function getLanguage(slug: string) {
  return LANGUAGES.find((l) => l.slug === slug);
}
