import { useEffect, useRef, useState } from "react";
import type { Language } from "@/lib/languages";

type Props = { language: Language };

export function CodePlayground({ language }: Props) {
  const [code, setCode] = useState(language.defaultCode);
  const [output, setOutput] = useState("");
  const [running, setRunning] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    setCode(language.defaultCode);
    setOutput("");
  }, [language.slug, language.defaultCode]);

  const run = async () => {
    setRunning(true);
    setOutput("جاري التنفيذ...");
    try {
      if (language.preview === "html" || language.preview === "css") {
        const doc = iframeRef.current?.contentDocument;
        if (doc) {
          doc.open();
          doc.write(code);
          doc.close();
        }
        setOutput("✓ تم عرض الصفحة");
      } else if (language.piston) {
        const res = await fetch("https://emkc.org/api/v2/piston/execute", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            language: language.piston.language,
            version: language.piston.version,
            files: [{ content: code }],
          }),
        });
        const data = await res.json();
        const out = data?.run?.output ?? data?.message ?? "لا يوجد ناتج";
        setOutput(out || "(بدون مخرجات)");
      } else {
        setOutput(
          "التنفيذ المباشر غير متاح لهذه اللغة داخل المتصفح. راجع الدروس والأمثلة.",
        );
      }
    } catch (e) {
      setOutput("خطأ في التنفيذ: " + (e as Error).message);
    } finally {
      setRunning(false);
    }
  };

  const isPreview = language.preview === "html" || language.preview === "css";

  return (
    <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-[var(--shadow-glow)]">
      <div className="flex items-center justify-between border-b border-border bg-secondary/50 px-4 py-3">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-red-500" />
          <span className="h-3 w-3 rounded-full bg-yellow-500" />
          <span className="h-3 w-3 rounded-full bg-green-500" />
          <span className="ms-3 text-sm text-muted-foreground">
            محرر {language.name}
          </span>
        </div>
        <button
          onClick={run}
          disabled={running}
          className="rounded-lg bg-primary px-4 py-1.5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-50"
        >
          {running ? "..." : "▶ تشغيل"}
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          dir="ltr"
          spellCheck={false}
          className="min-h-[360px] w-full resize-none bg-[oklch(0.13_0.02_260)] p-4 font-mono text-sm text-foreground outline-none"
        />
        <div className="min-h-[360px] border-t border-border md:border-s md:border-t-0 bg-[oklch(0.11_0.02_260)]">
          {isPreview ? (
            <iframe
              ref={iframeRef}
              title="preview"
              className="h-full min-h-[360px] w-full bg-white"
            />
          ) : (
            <pre
              dir="ltr"
              className="h-full min-h-[360px] whitespace-pre-wrap p-4 font-mono text-sm text-green-300"
            >
              {output || "// اضغط تشغيل لرؤية الناتج"}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
}
