'use client'

import { useState } from 'react'

export default function Header() {
  const [isDark, setIsDark] = useState(false)

  const toggleTheme = () => {
    const html = document.documentElement
    html.classList.toggle('dark', !isDark)
    setIsDark(!isDark)
  }

  return (
    <header className="sticky top-0 z-50 border-b" style={{ borderColor: 'var(--border)', backgroundColor: 'var(--background)' }}>
      <div className="container mx-auto px-4 py-6 flex items-center justify-between max-w-7xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl font-bold text-white" style={{ background: 'linear-gradient(135deg, var(--accent), var(--secondary))' }}>
            {'<'}
          </div>
          <div>
            <h1 className="text-2xl font-bold" style={{ color: 'var(--accent)' }}>
              أكاديمية البرمجة
            </h1>
            <p className="text-sm" style={{ color: 'var(--muted-foreground)' }}>
              تعلم 8 لغات برمجة
            </p>
          </div>
        </div>

        <button
          onClick={toggleTheme}
          className="px-4 py-2 rounded-lg font-medium transition-all duration-200 hover:scale-105"
          style={{
            backgroundColor: isDark ? 'var(--primary)' : 'var(--secondary)',
            color: 'white',
          }}
        >
          {isDark ? '☀️' : '🌙'}
        </button>
      </div>
    </header>
  )
}
