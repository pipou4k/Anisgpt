'use client'

import { useEffect, useState } from 'react'

export default function HeroSection() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <section
      className="relative py-20 overflow-hidden"
      style={{ backgroundColor: 'var(--background)' }}
    >
      {/* Decorative Elements */}
      <div
        className="absolute top-10 right-10 w-64 h-64 rounded-full opacity-10 blur-3xl"
        style={{
          background: 'linear-gradient(135deg, var(--accent), var(--secondary))',
          transform: `translateY(${scrollY * 0.5}px)`,
        }}
      />
      <div
        className="absolute bottom-0 left-10 w-80 h-80 rounded-full opacity-10 blur-3xl"
        style={{
          background: 'linear-gradient(135deg, var(--secondary), var(--accent))',
          transform: `translateY(${scrollY * -0.3}px)`,
        }}
      />

      <div className="container mx-auto px-4 max-w-7xl relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-6xl font-black mb-4 leading-tight" style={{ color: 'var(--foreground)' }}>
            <span style={{ background: 'linear-gradient(135deg, var(--accent), var(--secondary))', backgroundClip: 'text', WebkitBackgroundClip: 'text', color: 'transparent' }}>
              تعلم البرمجة
            </span>
            <br />
            بطريقة احترافية وممتعة
          </h2>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto" style={{ color: 'var(--muted-foreground)' }}>
            اختر من بين 8 لغات برمجة مختلفة، من المبتدئ إلى المتقدم، وتعلم المهارات العملية التي تحتاجها في سوق العمل
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              className="px-8 py-4 rounded-lg font-bold text-white transition-all duration-200 hover:scale-105"
              style={{
                background: 'linear-gradient(135deg, var(--accent), var(--secondary))',
              }}
            >
              ابدأ التعلم الآن
            </button>
            <button
              className="px-8 py-4 rounded-lg font-bold transition-all duration-200 hover:scale-105 border-2"
              style={{
                borderColor: 'var(--accent)',
                color: 'var(--accent)',
              }}
            >
              اعرف المزيد
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 md:gap-8 mt-16 pb-8 border-t border-b" style={{ borderColor: 'var(--border)' }}>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold" style={{ color: 'var(--accent)' }}>8</p>
            <p className="text-sm md:text-base" style={{ color: 'var(--muted-foreground)' }}>لغات برمجة</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold" style={{ color: 'var(--accent)' }}>150+</p>
            <p className="text-sm md:text-base" style={{ color: 'var(--muted-foreground)' }}>درس تفاعلي</p>
          </div>
          <div className="text-center">
            <p className="text-3xl md:text-4xl font-bold" style={{ color: 'var(--accent)' }}>100%</p>
            <p className="text-sm md:text-base" style={{ color: 'var(--muted-foreground)' }}>مجاني</p>
          </div>
        </div>
      </div>
    </section>
  )
}
