'use client';

import React, { useRef, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { PerspectiveCamera, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

interface Emoji3DProps {
  emoji: string;
  scale?: number;
  speed?: number;
}

function EmojiMesh({ emoji, scale = 2, speed = 0.01 }: Emoji3DProps) {
  const groupRef = useRef<THREE.Group>(null);
  const meshRef = useRef<THREE.Mesh>(null);

  useEffect(() => {
    // Create a canvas texture from emoji
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    if (ctx) {
      ctx.fillStyle = 'transparent';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.font = 'bold 380px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(emoji, canvas.width / 2, canvas.height / 2);

      const texture = new THREE.CanvasTexture(canvas);
      texture.magFilter = THREE.LinearFilter;
      texture.minFilter = THREE.LinearFilter;

      // Create geometry and material with better visuals
      const geometry = new THREE.PlaneGeometry(scale, scale);
      const material = new THREE.MeshStandardMaterial({
        map: texture,
        transparent: true,
        emissive: 0xffffff,
        emissiveIntensity: 0.4,
        metalness: 0.3,
        roughness: 0.4,
      });

      if (groupRef.current) {
        // Remove old mesh if exists
        if (meshRef.current) {
          meshRef.current.geometry.dispose();
          (meshRef.current.material as THREE.Material).dispose();
          groupRef.current.remove(meshRef.current);
        }

        // Create new mesh
        const mesh = new THREE.Mesh(geometry, material);
        meshRef.current = mesh;
        groupRef.current.add(mesh);
      }
    }
  }, [emoji, scale]);

  useFrame(({ clock }) => {
    if (groupRef.current && meshRef.current) {
      groupRef.current.rotation.x = Math.sin(clock.elapsedTime * speed) * 0.3;
      groupRef.current.rotation.y += speed * 1.2;
      
      // Add subtle scale animation
      const scale = 1 + Math.sin(clock.elapsedTime * 1.5) * 0.05;
      meshRef.current.scale.set(scale, scale, 1);
    }
  });

  return <group ref={groupRef} />;
}

export default function Emoji3D({
  emoji,
  scale = 2,
  speed = 0.01,
}: Emoji3DProps) {
  return (
    <div style={{ width: '100%', height: '100%', minHeight: '200px' }}>
      <Canvas dpr={[1, 2]}>
        <PerspectiveCamera makeDefault position={[0, 0, 4]} />
        <ambientLight intensity={1} />
        <directionalLight position={[5, 5, 5]} intensity={1.2} />
        <pointLight position={[5, 5, 5]} intensity={0.8} color={0xd8b4ff} />
        <pointLight position={[-5, -5, 5]} intensity={0.6} color={0x8f64c8} />
        <EmojiMesh emoji={emoji} scale={scale} speed={speed} />
        <OrbitControls autoRotate autoRotateSpeed={4} enableZoom={false} enablePan={false} />
      </Canvas>
    </div>
  );
}
