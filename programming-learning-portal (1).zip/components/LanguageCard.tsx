'use client'

import { useState } from 'react'
import dynamic from 'next/dynamic'

const Emoji3D = dynamic(() => import('./Emoji3D'), { ssr: false })

interface LanguageCardProps {
  id: number
  name: string
  description: string
  emoji: string
  color: string
  lessons: number
  difficulty: string
}

export default function LanguageCard({ id, name, description, emoji, color, lessons, difficulty }: LanguageCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  const getDifficultyColor = (level: string) => {
    switch (level) {
      case 'مبتدئ':
        return '#10b981'
      case 'متوسط':
        return '#f59e0b'
      case 'متقدم':
        return '#ef4444'
      default:
        return 'var(--accent)'
    }
  }

  return (
    <div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="rounded-xl p-6 cursor-pointer transition-all duration-300 transform hover:scale-105"
      style={{
        backgroundColor: isHovered ? 'var(--card)' : 'var(--card)',
        border: `2px solid ${color}`,
        boxShadow: isHovered ? `0 12px 24px ${color}33` : '0 4px 12px rgba(0,0,0,0.1)',
      }}
    >
      {/* Header Icon 3D */}
      <div className="mb-4 h-40 rounded-lg overflow-hidden" style={{ backgroundColor: 'rgba(143, 100, 200, 0.1)' }}>
        <Emoji3D emoji={emoji} scale={1.8} speed={0.008} />
      </div>

      {/* Title */}
      <h3 className="text-2xl font-bold mb-2" style={{ color: 'var(--foreground)' }}>
        {name}
      </h3>

      {/* Description */}
      <p className="text-sm mb-4 line-clamp-2" style={{ color: 'var(--muted-foreground)' }}>
        {description}
      </p>

      {/* Stats */}
      <div className="flex gap-4 mb-4 pb-4 border-b" style={{ borderColor: 'var(--border)' }}>
        <div className="flex-1">
          <p className="text-xs font-semibold opacity-70" style={{ color: 'var(--muted-foreground)' }}>
            الدروس
          </p>
          <p className="text-lg font-bold" style={{ color: color }}>
            {lessons}
          </p>
        </div>
        <div className="flex-1">
          <p className="text-xs font-semibold opacity-70" style={{ color: 'var(--muted-foreground)' }}>
            المستوى
          </p>
          <p
            className="text-lg font-bold"
            style={{ color: getDifficultyColor(difficulty) }}
          >
            {difficulty}
          </p>
        </div>
      </div>

      {/* Button */}
      <button
        className="w-full py-2 rounded-lg font-semibold transition-all duration-200 text-white hover:shadow-lg"
        style={{ backgroundColor: color }}
      >
        ابدأ التعلم
      </button>
    </div>
  )
}
