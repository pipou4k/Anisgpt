'use client'

import Header from '@/components/Header'
import HeroSection from '@/components/HeroSection'
import LanguageCard from '@/components/LanguageCard'

const languages = [
  {
    id: 1,
    name: 'Python',
    description: 'لغة سهلة وقوية لتطوير التطبيقات والذكاء الاصطناعي',
    emoji: '🐍',
    color: '#3776ab',
    lessons: 24,
    difficulty: 'مبتدئ',
  },
  {
    id: 2,
    name: 'JavaScript',
    description: 'لغة الويب الأساسية لتطوير التطبيقات التفاعلية',
    emoji: '⚡',
    color: '#f7df1e',
    lessons: 28,
    difficulty: 'مبتدئ',
  },
  {
    id: 3,
    name: 'Pawn',
    description: 'لغة برمجة متخصصة لتطوير ألعاب SA-MP',
    emoji: '🎮',
    color: '#e84c3d',
    lessons: 18,
    difficulty: 'متوسط',
  },
  {
    id: 4,
    name: 'HTML',
    description: 'لغة الترميز الأساسية لبناء صفحات الويب',
    emoji: '🏗️',
    color: '#e34c26',
    lessons: 16,
    difficulty: 'مبتدئ',
  },
  {
    id: 5,
    name: 'C++',
    description: 'لغة قوية وسريعة لتطوير التطبيقات الأساسية',
    emoji: '⚙️',
    color: '#00599c',
    lessons: 32,
    difficulty: 'متقدم',
  },
  {
    id: 6,
    name: 'CSS',
    description: 'لغة تصميم الويب لإنشاء واجهات جميلة',
    emoji: '🎨',
    color: '#1572b6',
    lessons: 20,
    difficulty: 'مبتدئ',
  },
  {
    id: 7,
    name: 'MySQL',
    description: 'قاعدة بيانات موثوقة لتخزين البيانات',
    emoji: '🗄️',
    color: '#00758f',
    lessons: 22,
    difficulty: 'متوسط',
  },
  {
    id: 8,
    name: 'PHP',
    description: 'لغة خادم قوية لتطوير تطبيقات الويب الديناميكية',
    emoji: '🖥️',
    color: '#777bb4',
    lessons: 26,
    difficulty: 'متوسط',
  },
]

export default function Page() {
  return (
    <main style={{ backgroundColor: 'var(--background)', color: 'var(--foreground)' }}>
      <Header />
      <HeroSection />

      {/* Languages Section */}
      <section className="py-16 md:py-24" style={{ backgroundColor: 'var(--background)' }}>
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="mb-12 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" style={{ color: 'var(--foreground)' }}>
              اختر لغة البرمجة التي تريد تعلمها
            </h2>
            <p className="text-lg" style={{ color: 'var(--muted-foreground)' }}>
              8 لغات متنوعة تغطي جميع مجالات البرمجة الحديثة
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {languages.map((lang) => (
              <LanguageCard key={lang.id} {...lang} />
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section
        className="py-16 md:py-24"
        style={{
          backgroundColor: 'var(--card)',
          borderTop: '1px solid var(--border)',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <div className="container mx-auto px-4 max-w-7xl">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12" style={{ color: 'var(--foreground)' }}>
            لماذا تختار أكاديمية البرمجة؟
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: '📚',
                title: 'محتوى شامل',
                description: 'دروس متقدمة من المبتدئ إلى الاحترافي',
              },
              {
                icon: '💻',
                title: 'تطبيق عملي',
                description: 'تمارين وتحديات واقعية لتطبيق ما تتعلمه',
              },
              {
                icon: '👨‍🏫',
                title: 'معلمون خبراء',
                description: 'تعليم من محترفين في مجال البرمجة',
              },
              {
                icon: '🏆',
                title: 'شهادات معترف بها',
                description: 'احصل على شهادات عند إكمال كل لغة',
              },
              {
                icon: '🤝',
                title: 'مجتمع نشط',
                description: 'تواصل مع متعلمين آخرين وشارك تجاربك',
              },
              {
                icon: '🎯',
                title: 'دعم كامل',
                description: 'حصول على الدعم والمساعدة المستمرة',
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="rounded-lg p-6 text-center transition-all duration-200 hover:scale-105"
                style={{
                  backgroundColor: 'var(--background)',
                  border: '1px solid var(--border)',
                }}
              >
                <p className="text-4xl mb-3">{feature.icon}</p>
                <h3 className="text-xl font-bold mb-2" style={{ color: 'var(--foreground)' }}>
                  {feature.title}
                </h3>
                <p style={{ color: 'var(--muted-foreground)' }}>
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24" style={{ backgroundColor: 'var(--background)' }}>
        <div className="container mx-auto px-4 max-w-7xl">
          <div
            className="rounded-2xl p-12 text-center"
            style={{
              background: 'linear-gradient(135deg, var(--accent), var(--secondary))',
            }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              هل أنت مستعد لبدء رحلتك البرمجية؟
            </h2>
            <p className="text-lg mb-8 text-white opacity-90">
              انضم إلى آلاف المتعلمين الذين غيرت البرمجة حياتهم المهنية
            </p>
            <button
              className="px-8 py-4 rounded-lg font-bold text-lg transition-all duration-200 hover:scale-105"
              style={{
                backgroundColor: 'white',
                color: 'var(--accent)',
              }}
            >
              ابدأ الآن مجاناً
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer
        className="py-8 border-t"
        style={{
          backgroundColor: 'var(--card)',
          borderColor: 'var(--border)',
        }}
      >
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="font-bold mb-3" style={{ color: 'var(--foreground)' }}>
                عن الأكاديمية
              </h3>
              <p style={{ color: 'var(--muted-foreground)' }}>
                منصة تعليمية متخصصة في تعليم البرمجة للجميع
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-3" style={{ color: 'var(--foreground)' }}>
                الروابط السريعة
              </h3>
              <ul className="space-y-2">
                <li><a href="#" style={{ color: 'var(--muted-foreground)' }} className="hover:text-accent">الدورات</a></li>
                <li><a href="#" style={{ color: 'var(--muted-foreground)' }} className="hover:text-accent">الشهادات</a></li>
                <li><a href="#" style={{ color: 'var(--muted-foreground)' }} className="hover:text-accent">المنتدى</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-3" style={{ color: 'var(--foreground)' }}>
                تواصل معنا
              </h3>
              <ul className="space-y-2">
                <li><a href="#" style={{ color: 'var(--muted-foreground)' }} className="hover:text-accent">البريد الإلكتروني</a></li>
                <li><a href="#" style={{ color: 'var(--muted-foreground)' }} className="hover:text-accent">تويتر</a></li>
                <li><a href="#" style={{ color: 'var(--muted-foreground)' }} className="hover:text-accent">تيليجرام</a></li>
              </ul>
            </div>
          </div>

          <div
            className="pt-8 border-t text-center"
            style={{
              borderColor: 'var(--border)',
              color: 'var(--muted-foreground)',
            }}
          >
            <p>&copy; 2024 أكاديمية البرمجة. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </main>
  )
}
